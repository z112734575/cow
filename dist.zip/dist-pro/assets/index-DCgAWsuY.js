import{r as t}from"./index-TwgnzE1J.js";const r=()=>t.get({url:"/mock/menu/list"});export{r as g};
