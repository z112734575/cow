const a=""+new URL("avatar-Cwy0s6ay.jpg",import.meta.url).href;export{a as _};
