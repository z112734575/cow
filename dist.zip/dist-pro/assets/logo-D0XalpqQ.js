const o=""+new URL("logo-CRQ9AZN7.png",import.meta.url).href;export{o as _};
