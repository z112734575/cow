import{r as e}from"./index-TwgnzE1J.js";const t=()=>e.get({url:"/mock/role/table"});export{t as g};
