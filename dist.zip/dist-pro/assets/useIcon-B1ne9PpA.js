import{I as r}from"./index-TwgnzE1J.js";import{ac as s}from"./vue-chunks-mpUGqK7y.js";const c=o=>s(r,o);export{c as u};
